# python
# services/summarize_service.py

from .summarize_helpers import sbar_from_notes
# no self-import

def sbar_from_notes(notes):
    # implementation
    return "..."