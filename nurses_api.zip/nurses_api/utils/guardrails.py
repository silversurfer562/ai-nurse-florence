EDU_BANNER = "Draft for clinician review — not medical advice. No PHI stored."


def educational_banner():
    return EDU_BANNER
